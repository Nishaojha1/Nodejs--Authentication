module.exports = {
    MongoURI: "mongodb+srv://Sachiii:Sachiii@cluster0.qfobsr3.mongodb.net/NodeJS?retryWrites=true&w=majority"
}