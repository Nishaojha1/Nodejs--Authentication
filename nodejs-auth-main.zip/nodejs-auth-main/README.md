# Nodejs-Auth
Using Nodejs, ejs, MongoDB, and Passport 


![Screenshot (56)](https://user-images.githubusercontent.com/100932180/188841044-4577ad50-fe2c-466c-9bd8-87645fe4c285.png)

![Screenshot (57)](https://user-images.githubusercontent.com/100932180/188841061-e423b928-24e7-4834-9a6f-09e7ee665e73.png)

![Screenshot (58)](https://user-images.githubusercontent.com/100932180/188841075-1f33e64b-c334-4d03-9418-3d4e25f0c3c6.png)

![Screenshot (59)](https://user-images.githubusercontent.com/100932180/188841095-7ac5a7c8-09e2-4384-ae7e-f56339db6015.png)

![Screenshot (60)](https://user-images.githubusercontent.com/100932180/188841115-2f44bd4f-31cd-4c37-83b6-6a6ca7db3abe.png)
